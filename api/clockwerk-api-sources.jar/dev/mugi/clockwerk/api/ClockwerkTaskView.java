package dev.mugi.clockwerk.api;

import java.time.Instant;
import java.util.Optional;

/**
 * A read-only snapshot of one scheduled task.
 *
 * <p>Values, not references: what a listener sees is the task as it was when the
 * event fired, so a task edited mid-event cannot change what the listener is
 * already looking at.
 *
 * @param id the unique id, as used in {@code /cw run <id>} and in {@code tasks.yml}
 * @param name the display name shown in the GUI
 * @param type what the task does when it fires
 * @param kind how often it fires
 * @param scheduleDetail the schedule's parameters, human-readable and in English
 * @param payload the action's content: the message, the command, or the bossbar title
 * @param missedPolicy what happens to runs the server slept through
 * @param enabled whether the task is armed; a paused task never fires
 * @param lastRun when the task last executed, empty if never
 * @param nextRun when the task will next execute, empty if it will never again
 */
public record ClockwerkTaskView(String id, String name, TaskType type, ScheduleKind kind, String scheduleDetail,
        String payload, MissedPolicy missedPolicy, boolean enabled, Optional<Instant> lastRun, Optional<Instant> nextRun) {
}
