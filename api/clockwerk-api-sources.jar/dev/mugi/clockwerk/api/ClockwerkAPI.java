package dev.mugi.clockwerk.api;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * The one interface another plugin needs in order to read and change Clockwerk's
 * schedule.
 *
 * <p>Obtain it from the Bukkit services manager, which also lets your plugin ask
 * whether Clockwerk is installed instead of catching a class-not-found:
 *
 * <pre>{@code
 * ClockwerkAPI api = Bukkit.getServicesManager().load(ClockwerkAPI.class);
 * if (api == null) {
 *     return; // Clockwerk is not installed, or has not enabled yet
 * }
 * api.getNextRun("nightly-restart").ifPresent(when -> ...);
 * }</pre>
 *
 * <p>Declare Clockwerk in your {@code plugin.yml} ({@code depend} or
 * {@code softdepend}) so the server lets you load this interface at runtime, and
 * build against the {@code clockwerk-api} artifact with {@code provided} scope
 * so it is never bundled into your own jar.
 *
 * <p>All methods are thread-safe: they may be called from any thread, including
 * inside {@link dev.mugi.clockwerk.api.event.TaskExecuteEvent}, which fires on
 * whatever thread Clockwerk executed the task from.
 */
public interface ClockwerkAPI {

    /**
     * Every task currently loaded, enabled or not, in no particular order.
     *
     * @return a snapshot; the collection is a copy and cannot be modified
     */
    Collection<ClockwerkTaskView> getTasks();

    /**
     * Looks up one task by id.
     *
     * @param id the task id, as in {@code /cw run <id>}
     * @return the task, or empty when no such task exists
     */
    Optional<ClockwerkTaskView> getTask(String id);

    /**
     * When the task will next execute.
     *
     * <p>A paused task, a ONCE task that already ran, and a task with no future
     * occurrence all come back empty rather than as a stale time.
     *
     * @param id the task id
     * @return the next run, or empty
     */
    Optional<Instant> getNextRun(String id);

    /**
     * The next runs across every enabled task, soonest first.
     *
     * <p>The list behind the GUI's upcoming screen, exposed because "what is this
     * server going to do in the next hours" is a question other plugins ask too.
     *
     * @param max how many entries to return, at most
     * @return the upcoming runs; empty when nothing is scheduled
     */
    List<UpcomingRun> getUpcoming(int max);

    /**
     * Creates a task from a draft and persists it.
     *
     * <p>Fails with {@code false} when the id is already taken, which is the only
     * expected collision; a draft that did not pass {@link ClockwerkTaskDraft#build()}
     * throws from the draft itself before reaching here.
     *
     * @param draft the fully built draft
     * @return the created task's view
     * @throws IllegalStateException when a task with the draft's id already exists
     */
    ClockwerkTaskView createTask(ClockwerkTaskDraft draft);

    /**
     * Deletes a task and its history.
     *
     * @param id the task id
     * @return {@code true} when a task was actually removed
     */
    boolean deleteTask(String id);

    /**
     * Pauses or resumes a task. A paused task keeps its schedule and its next
     * run is not computed; resuming recomputes from that moment.
     *
     * @param id the task id
     * @param enabled whether the task should be armed
     * @return {@code true} when the task exists and the state changed
     */
    boolean setEnabled(String id, boolean enabled);
}
