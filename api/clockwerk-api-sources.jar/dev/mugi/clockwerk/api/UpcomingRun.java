package dev.mugi.clockwerk.api;

import java.time.Instant;

/**
 * One entry of the global upcoming-runs list: a task and the moment it fires.
 *
 * @param taskId the task's id
 * @param taskName the task's display name
 * @param type what the task does
 * @param when the scheduled moment
 */
public record UpcomingRun(String taskId, String taskName, TaskType type, Instant when) {
}
