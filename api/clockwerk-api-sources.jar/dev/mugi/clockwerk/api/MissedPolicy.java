package dev.mugi.clockwerk.api;

/**
 * What Clockwerk does with a run that was missed because the server was offline.
 *
 * <p>This is the setting that exists because every other scheduler gets it wrong:
 * a restart scheduled at 04:00 that fires the moment a morning boot finishes is a
 * worse bug than a restart that did not happen at all.
 */
public enum MissedPolicy {
    /** Drop the run and wait for the next scheduled time. The safe default. */
    SKIP,
    /** Run once on the next startup, then continue on the normal schedule. */
    RUN_ON_STARTUP,
    /** Run every missed occurrence in order, as soon as the server is back. */
    CATCHUP
}
