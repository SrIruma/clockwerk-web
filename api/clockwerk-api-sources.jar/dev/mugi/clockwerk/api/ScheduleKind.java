package dev.mugi.clockwerk.api;

/**
 * The shape of a task's schedule, for consumers that want more than a description.
 *
 * <p>Pairs with {@link ClockwerkTaskView#scheduleDetail()}, which holds the
 * parameters in a human-readable form: {@code "04:00"} for {@link #DAILY},
 * {@code "every 15 minutes"} for {@link #INTERVAL}, the expression itself for
 * {@link #CRON}, and so on.
 */
public enum ScheduleKind {
    /** A single date and time, then never again. */
    ONCE,
    /** Every day at a fixed time. */
    DAILY,
    /** Every week on a fixed day and time. */
    WEEKLY,
    /** A fixed gap between runs. */
    INTERVAL,
    /** A five-field cron expression. */
    CRON
}
