package dev.mugi.clockwerk.api;

import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/**
 * Everything needed to create a task, built without touching Clockwerk internals.
 *
 * <p>Exactly one schedule must be chosen. The builder validates that on
 * {@link #build()} rather than on each with-method, so a draft assembled over
 * several statements still fails as one clear error.
 *
 * <pre>{@code
 * ClockwerkTaskDraft draft = ClockwerkTaskDraft.of("nightly-restart")
 *     .named("Nightly restart")
 *     .type(TaskType.RESTART)
 *     .dailyAt(LocalTime.of(4, 0))
 *     .missedPolicy(MissedPolicy.SKIP)
 *     .warnSecondsBefore(300, 60, 30)
 *     .build();
 * api.createTask(draft);
 * }</pre>
 */
public final class ClockwerkTaskDraft {

    private final String id;
    private String name;
    private TaskType type;
    private String payload;

    private ScheduleKind kind;
    private Instant onceAt;
    private LocalTime dailyTime;
    private DayOfWeek weeklyDay;
    private LocalTime weeklyTime;
    private int intervalMinutes;
    private String cronExpression;

    private MissedPolicy missedPolicy = MissedPolicy.SKIP;
    private final List<Integer> warnSecondsBefore = new ArrayList<>();

    private ClockwerkTaskDraft(String id) {
        this.id = id;
    }

    /**
     * Starts a draft. The id becomes the task's permanent identity, so it should
     * be stable: lowercase, no spaces, unique among the server's tasks.
     *
     * @param id the unique task id
     * @return the draft, ready to configure
     */
    public static ClockwerkTaskDraft of(String id) {
        Objects.requireNonNull(id, "id");
        return new ClockwerkTaskDraft(id.trim().toLowerCase(Locale.ROOT));
    }

    /** @param name the display name shown in the GUI */
    public ClockwerkTaskDraft named(String name) {
        this.name = Objects.requireNonNull(name, "name");
        return this;
    }

    /** @param type what the task does when it fires */
    public ClockwerkTaskDraft type(TaskType type) {
        this.type = Objects.requireNonNull(type, "type");
        return this;
    }

    /**
     * The action's content. For {@link TaskType#BROADCAST} and
     * {@link TaskType#BOSSBAR} it is the message (legacy {@code &} colours are
     * accepted); for the two command types it is the command without a leading
     * slash; ignored for {@link TaskType#RESTART}.
     *
     * @param payload the message or command
     */
    public ClockwerkTaskDraft payload(String payload) {
        this.payload = Objects.requireNonNull(payload, "payload");
        return this;
    }

    /** Runs once at the given moment and never again. */
    public ClockwerkTaskDraft onceAt(Instant when) {
        this.kind = ScheduleKind.ONCE;
        this.onceAt = Objects.requireNonNull(when, "when");
        return this;
    }

    /** Runs every day at the given local time. */
    public ClockwerkTaskDraft dailyAt(LocalTime time) {
        this.kind = ScheduleKind.DAILY;
        this.dailyTime = Objects.requireNonNull(time, "time");
        return this;
    }

    /** Runs every week on the given day and time. */
    public ClockwerkTaskDraft weeklyAt(DayOfWeek day, LocalTime time) {
        this.kind = ScheduleKind.WEEKLY;
        this.weeklyDay = Objects.requireNonNull(day, "day");
        this.weeklyTime = Objects.requireNonNull(time, "time");
        return this;
    }

    /** Runs every {@code minutes}, as long as the gap is at least one minute. */
    public ClockwerkTaskDraft everyMinutes(int minutes) {
        if (minutes < 1) {
            throw new IllegalArgumentException("interval must be at least 1 minute");
        }
        this.kind = ScheduleKind.INTERVAL;
        this.intervalMinutes = minutes;
        return this;
    }

    /** Runs on a five-field cron expression ({@code minute hour dom month dow}). */
    public ClockwerkTaskDraft cron(String expression) {
        this.kind = ScheduleKind.CRON;
        this.cronExpression = Objects.requireNonNull(expression, "expression");
        return this;
    }

    /** @param policy what happens to runs the server slept through */
    public ClockwerkTaskDraft missedPolicy(MissedPolicy policy) {
        this.missedPolicy = Objects.requireNonNull(policy, "policy");
        return this;
    }

    /**
     * Seconds before each run at which a warning fires, largest first. Empty
     * means no warnings; a RESTART with no warnings stops the server silently.
     *
     * @param seconds the offsets, in seconds before the run
     */
    public ClockwerkTaskDraft warnSecondsBefore(int... seconds) {
        this.warnSecondsBefore.clear();
        for (int s : seconds) {
            if (s > 0) {
                this.warnSecondsBefore.add(s);
            }
        }
        Collections.sort(this.warnSecondsBefore, Collections.reverseOrder());
        return this;
    }

    /** @return the task id */
    public String id() {
        return this.id;
    }

    /** @return the display name, or the id when none was set */
    public String name() {
        return (this.name == null || this.name.isBlank()) ? this.id : this.name;
    }

    /** @return what the task does */
    public TaskType type() {
        return this.type;
    }

    /** @return the action's content, empty string when none was set */
    public String payload() {
        return (this.payload == null) ? "" : this.payload;
    }

    /** @return how often the task fires */
    public ScheduleKind kind() {
        return this.kind;
    }

    /** @return the schedule's parameters, for the core to turn into a spec */
    public ScheduleParams params() {
        return new ScheduleParams(this.kind, this.onceAt, this.dailyTime, this.weeklyDay, this.weeklyTime,
                this.intervalMinutes, this.cronExpression);
    }

    /** @return what happens to missed runs */
    public MissedPolicy missedPolicy() {
        return this.missedPolicy;
    }

    /** @return the warning offsets, largest first */
    public List<Integer> warnSecondsBefore() {
        return List.copyOf(this.warnSecondsBefore);
    }

    /**
     * Checks that every required piece is present and throws the first problem
     * found, with a message an API consumer can show to their own admin.
     *
     * @return this draft, for chaining
     * @throws IllegalStateException if a schedule, a type or an id is missing
     */
    public ClockwerkTaskDraft build() {
        if (this.id.isBlank()) {
            throw new IllegalStateException("task id must not be blank");
        }
        if (this.type == null) {
            throw new IllegalStateException("task '" + this.id + "' has no type");
        }
        if (this.kind == null) {
            throw new IllegalStateException("task '" + this.id + "' has no schedule");
        }
        switch (this.kind) {
            case ONCE -> {
                if (this.onceAt == null) {
                    throw new IllegalStateException("task '" + this.id + "' is ONCE but has no date");
                }
            }
            case DAILY -> {
                if (this.dailyTime == null) {
                    throw new IllegalStateException("task '" + this.id + "' is DAILY but has no time");
                }
            }
            case WEEKLY -> {
                if (this.weeklyDay == null || this.weeklyTime == null) {
                    throw new IllegalStateException("task '" + this.id + "' is WEEKLY but has no day or time");
                }
            }
            case INTERVAL -> {
                if (this.intervalMinutes < 1) {
                    throw new IllegalStateException("task '" + this.id + "' is INTERVAL but has no gap");
                }
            }
            case CRON -> {
                if (this.cronExpression == null || this.cronExpression.isBlank()) {
                    throw new IllegalStateException("task '" + this.id + "' is CRON but has no expression");
                }
            }
        }
        if (this.type == TaskType.RESTART || this.type == TaskType.BOSSBAR || this.type == TaskType.BROADCAST) {
            if (this.payload == null || this.payload.isBlank()) {
                throw new IllegalStateException("task '" + this.id + "' needs a payload");
            }
        }
        if ((this.type == TaskType.CONSOLE_COMMAND || this.type == TaskType.PLAYER_COMMAND)
                && (this.payload == null || this.payload.isBlank())) {
            throw new IllegalStateException("task '" + this.id + "' needs a command");
        }
        return this;
    }

    /**
     * The schedule parameters as one value, so the core can map a draft to its
     * own spec without the API exposing every field individually.
     *
     * @param kind the schedule kind
     * @param onceAt the moment, for ONCE
     * @param dailyTime the time, for DAILY
     * @param weeklyDay the day, for WEEKLY
     * @param weeklyTime the time, for WEEKLY
     * @param intervalMinutes the gap, for INTERVAL
     * @param cronExpression the expression, for CRON
     */
    public record ScheduleParams(ScheduleKind kind, Instant onceAt, LocalTime dailyTime, DayOfWeek weeklyDay,
            LocalTime weeklyTime, int intervalMinutes, String cronExpression) {
    }
}
