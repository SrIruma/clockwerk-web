package dev.mugi.clockwerk.api;

/**
 * What a task does when it fires.
 *
 * <p>The same five kinds the GUI offers. Kept in the API module so a listener can
 * branch on {@link ClockwerkTaskView#type()} without loading core classes.
 */
public enum TaskType {
    /** Sends a chat message to the whole server. */
    BROADCAST,
    /** Runs a command as the console. */
    CONSOLE_COMMAND,
    /** Runs a command as every online player, one at a time. */
    PLAYER_COMMAND,
    /** Stops the server after the configured warnings. */
    RESTART,
    /** Shows a bossbar to the whole server for a number of seconds. */
    BOSSBAR
}
