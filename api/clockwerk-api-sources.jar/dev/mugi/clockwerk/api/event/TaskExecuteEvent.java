package dev.mugi.clockwerk.api.event;

import dev.mugi.clockwerk.api.ClockwerkTaskView;
import java.time.Instant;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * Fired right before a task's action runs, on whatever thread Clockwerk
 * executes that action from (the global region thread on Folia, the main thread
 * on Paper).
 *
 * <p>Cancelling this event drops the run: the action does not execute, a
 * {@link TaskSkippedEvent} with {@link TaskSkippedEvent.Reason#CANCELLED} fires
 * in its place, and the task's next run is still computed. That makes it the
 * hook for "do not restart while a world backup is running" and for the
 * countless "only if nobody is fighting" conditions.
 *
 * <p>Run this asynchronously-safe: a listener that touches entities or blocks
 * must reschedule onto the right thread itself.
 */
public class TaskExecuteEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();

    private final ClockwerkTaskView task;
    private final Instant scheduledFor;
    private final boolean manual;
    private boolean cancelled;

    /**
     * @param task the task about to run
     * @param scheduledFor the moment this run was scheduled for; equals "now" for
     *                     a manual run
     * @param manual whether an admin triggered this run instead of the clock
     */
    public TaskExecuteEvent(@NotNull ClockwerkTaskView task, @NotNull Instant scheduledFor, boolean manual) {
        this.task = task;
        this.scheduledFor = scheduledFor;
        this.manual = manual;
    }

    /** @return the task about to run */
    @NotNull
    public ClockwerkTaskView getTask() {
        return this.task;
    }

    /** @return the moment this run was scheduled for */
    @NotNull
    public Instant getScheduledFor() {
        return this.scheduledFor;
    }

    /** @return {@code true} when an admin ran the task by hand, not the clock */
    public boolean isManual() {
        return this.manual;
    }

    @Override
    public boolean isCancelled() {
        return this.cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @NotNull
    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    @NotNull
    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
