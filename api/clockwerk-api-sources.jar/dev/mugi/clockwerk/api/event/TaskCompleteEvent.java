package dev.mugi.clockwerk.api.event;

import dev.mugi.clockwerk.api.ClockwerkTaskView;
import java.time.Instant;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * Fired after a task's action ran, whether it worked or threw.
 *
 * <p>The place to record metrics, mirror a restart into Discord, or clean up
 * something a task set up. Fired for every executed run, including manual ones;
 * a cancelled run fires {@link TaskSkippedEvent} instead and never reaches here.
 */
public class TaskCompleteEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final ClockwerkTaskView task;
    private final Instant executedAt;
    private final boolean manual;
    private final boolean success;

    /**
     * @param task the task that ran
     * @param executedAt when the action actually ran
     * @param manual whether an admin triggered this run by hand
     * @param success whether the action finished without throwing
     */
    public TaskCompleteEvent(@NotNull ClockwerkTaskView task, @NotNull Instant executedAt, boolean manual, boolean success) {
        this.task = task;
        this.executedAt = executedAt;
        this.manual = manual;
        this.success = success;
    }

    /** @return the task that ran */
    @NotNull
    public ClockwerkTaskView getTask() {
        return this.task;
    }

    /** @return when the action actually ran */
    @NotNull
    public Instant getExecutedAt() {
        return this.executedAt;
    }

    /** @return {@code true} when an admin ran the task by hand */
    public boolean isManual() {
        return this.manual;
    }

    /** @return {@code false} when the action threw */
    public boolean isSuccess() {
        return this.success;
    }

    @NotNull
    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    @NotNull
    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
