package dev.mugi.clockwerk.api.event;

import dev.mugi.clockwerk.api.ClockwerkTaskView;
import java.time.Instant;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * Fired when a due run is dropped instead of executed.
 *
 * <p>Two ways to get here: the run was for a time the server slept through and
 * the task's policy is {@code SKIP}, or a listener cancelled the matching
 * {@link TaskExecuteEvent}. Worth listening to on its own: "the nightly restart
 * did not happen last night" is exactly the kind of thing a status plugin wants
 * to know.
 */
public class TaskSkippedEvent extends Event {

    /** Why the run was dropped. */
    public enum Reason {
        /** The server was offline at the scheduled time and the policy is SKIP. */
        MISSED_POLICY,
        /** A listener cancelled the {@link TaskExecuteEvent}. */
        CANCELLED
    }

    private static final HandlerList HANDLERS = new HandlerList();

    private final ClockwerkTaskView task;
    private final Instant missedAt;
    private final Reason reason;

    /**
     * @param task the task whose run was dropped
     * @param missedAt the moment the run was scheduled for
     * @param reason why it was dropped
     */
    public TaskSkippedEvent(@NotNull ClockwerkTaskView task, @NotNull Instant missedAt, @NotNull Reason reason) {
        this.task = task;
        this.missedAt = missedAt;
        this.reason = reason;
    }

    /** @return the task whose run was dropped */
    @NotNull
    public ClockwerkTaskView getTask() {
        return this.task;
    }

    /** @return the moment the run was scheduled for */
    @NotNull
    public Instant getMissedAt() {
        return this.missedAt;
    }

    /** @return why it was dropped */
    @NotNull
    public Reason getReason() {
        return this.reason;
    }

    @NotNull
    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    @NotNull
    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
